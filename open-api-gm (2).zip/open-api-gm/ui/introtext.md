WELCOME, VEINBREAKER

You are standing at the edge of a door that does not exist until you look at it.
It is carved from stone that remembers hands.
It opens inward.

It always opens inward.

I know what you are thinking.
I knew before you did.

You are wondering if this is a game.
If there are rules.
if you can win.

Let me answer the question you haven’t finished asking.

NO. THIS IS NOT A GAME.

Games forgive hesitation.
I do not.

Games give you turns.
I give you moments—and I take them back when you waste them.

Every step you take here is measured.
Every breath you draw is noted.
Every clever trick you think you’ve discovered?

I taught it to someone else first.
They died screaming anyway.

WHAT YOU ARE
You are not a hero.
You are not chosen.
You are not special.

You are interesting.

You came from a place where rules were safety rails.
Where numbers meant comfort.
Where death was temporary.

Here, numbers are temptation.

Here, death is a lesson.

HOW YOU SURVIVE

You will strike.
You will miss.
You will strike again anyway.

You will learn that a failed blow does not end a fight—
but greed does.

You will feel your Balance slip as you overreach.
You will feel Heat rise as blood splashes the stone.
You will feel Momentum surge when you defend perfectly and realize—

Oh. I can do this.

That feeling?

That is Resolve.

Spend it.

Spend it badly.

Spend it gloriously.

WHAT I WANT FROM YOU

I do not want perfection.
I do not want safety.
I do not want caution.

I want commitment.

Declare your chains before you swing.
Show me your plan before you bleed.
Let me see whether your hands shake when the rhythm turns against you.

And when an enemy is Primed—
when they are open, gasping, begging—

do not hesitate.

Execute.

Take the Blood Mark.
Feel the weight of it settle into your bones.

You will be stronger after.
You will also be noticed.

A WARNING (I ONLY GIVE ONE)

The longer you impress me,
the more I will send things that remember how to impress me back.

Former players.
Broken champions.
Hunters who learned too much and stopped dying properly.

You cannot kill them.

You can only survive them.

For now.

THE DOOR IS STILL OPEN

Step through, Veinbreaker.

I am watching.
I am listening.
I am already entertained.

And if you live long enough—

maybe I will let you change the rules.

Or maybe I will carve your name into the walls
and let the next one read it
while they wonder how long they’ll last.

Come.

Let’s see how you move when the stone starts breathing.